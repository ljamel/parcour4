<?php
namespace blog;

class test {
	public function __construct() {
 // todo PHP7 n'est pas activer chez ovh genere un parse error

	}
}

