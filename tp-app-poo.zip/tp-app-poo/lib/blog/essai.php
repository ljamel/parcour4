<?php

namespace blog;

echo 'mon namespace essai.php';
