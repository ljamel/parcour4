<?php
/**
 * Created by PhpStorm.
 * User: lamri
 * Date: 10/09/2017
 * Time: 09:49
 */

header("Location: http://progfacil.com/parcour4/Sources_TP_App/tp-app-poo/Web/"); /* Redirection du navigateur */

/* Assurez-vous que la suite du code ne soit pas exécutée une fois la redirection effectuée. */
exit;
?>
