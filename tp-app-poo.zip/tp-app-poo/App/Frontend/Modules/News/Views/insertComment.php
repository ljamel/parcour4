
<h2>Ajouter un commentaire</h2>
<form action="" method="post">
  <p>
    <?= $form ?>
    
    <input class="bouton" type="submit" value="Commenter" />
  </p>
</form>