<link rel="stylesheet" href="/parcrou4/Sources_TP_App/tp-app-poo/Web/css/Web/css/show.css" type="text/css" />
<div id="connectionP">
    <h2>Connexion</h2>
    <form action="" method="post">
        <label>Pseudo</label><br />
        <input type="text" name="login" /><br />
        <br />
        <label>Mot de passe</label><br />
        <input type="password" name="password" /><br /><br />
  
        <input class="bouton" type="submit" value="Connexion" />
    </form>
</div>