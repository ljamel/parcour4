<h2>Modifier un commentaire</h2>
<form action="" method="post">
  <p>
    <?= $form ?>
    
    <input class="bouton" type="submit" value="Modifier" />
  </p>
</form>