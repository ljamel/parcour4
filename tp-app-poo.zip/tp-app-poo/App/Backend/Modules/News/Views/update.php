<h2>Modifier une news</h2>
<form action="" method="post">
  <p>
    <?= $form ?>

    <input class="bouton" type="submit" value="Modifier" />
  </p>
</form>

<!-- Pour que tinymce soit activer que pour la page ajout article et modifier article -->

<!-- Pour que tinymce ne soi activer que pour la page ajout article et modifier article -->
<script src="/parcour4/Sources_TP_App/tp-app-poo/Web/js/tinymce/js/tinymce/tinymce.js"></script>
<script src="/parcour4/Sources_TP_App/tp-app-poo/Web/js/tinymce.js"></script>